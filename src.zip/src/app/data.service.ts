import { Injectable } from '@angular/core';
@Injectable({
providedIn: 'root'
})
export class DataService {
trips = [


{id: 112, name: "To Maldive", PhoneNumber: "71567236", members:
"7", description: "112 MLD 236 7 / MEAB / 8 hours"},
{id: 29973, name: "To Maldive", PhoneNumber: "82328382", members:
"2", description:  "973 MLD 382 2 / MEAB / 8 hours" },
{id: 31232, name: "To Turkey", PhoneNumber: "22389321", members:
"2", description:  "232 TRK 321 2 / Turkish Airlines / 3 hours" },
{id: 42273, name: "To Finland", PhoneNumber: "98232322", members:
"1" , description:  "322 FND 273 1 / Qatar Airlines / 12 hours" }
];


contact = [

  {id: 1 , name: "Abbas Ali Naim", work : "Manager" , age : "22 Years" , phone : "81223902"}, 
  {id: 2 , name: "Kawthar" , work: "T-Manager" , age: "20 years" , phone : "81883743"}, 
  {id: 3 , name: "Nour ", work: "Hostess", age: "28 years", phone : "81999474" },
  {id: 3 , name: "Zahraa", work: "Hostess", age: "26 years" , phone : "81464823"},
  {id: 3 , name: "Ali", work: "Pilot", age: "24 years", phone : "81234594" }
]

constructor() { }

public getTrip():Array<{id, name, PhoneNumber, members , description}>{
return this.trips;
}

public getcontact():Array<{id, name, work, age , phone }>{
  return this.contact;
  }
}