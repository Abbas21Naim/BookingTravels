import { Component, OnInit } from '@angular/core';
import { BookingComponent } from '../booking/booking.component';
import { DataService } from '../data.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {


  constructor( public dataService : DataService) { }

  ngOnInit(): void {
       

  } 






headers = ["Destination", "Night Cost WeekDays", "Night Cost Holidays" , "Family Discount" ];

details = [{"Destination" : "Maldives", "Night Cost WeekDays" : "400$" , "Night Cost Holidays" : "600$" , "Family Discount" : "30%"} , 
{"Destination" : "Turkey", "Night Cost WeekDays" : "200$" , "Night Cost Holidays" : "350$" , "Family Discount" : "20%"},
{"Destination" : "Cyprus", "Night Cost WeekDays" : "250$" , "Night Cost Holidays" : "300$" , "Family Discount" : "No Discounts"},
{"Destination" : "Russia", "Night Cost WeekDays" : "500$" , "Night Cost Holidays" : "No holidays" , "Family Discount" : "15%"},
{"Destination" : "Finland", "Night Cost WeekDays" : "No weekDays" , "Night Cost Holidays" : "800$" , "Family Discount" : "10%"},
{"Destination" : "Italy", "Night Cost WeekDays" : "640$" , "Night Cost Holidays" : "700$" , "Family Discount" : "10%"},
{"Destination" : "Thailand", "Night Cost WeekDays" : "840$" , "Night Cost Holidays" : "970$" , "Family Discount" : "20%"},
{"Destination" : "Austria", "Night Cost WeekDays" : "950$" , "Night Cost Holidays" : "1000$" , "Family Discount" : "30%"},
{"Destination" : "Malaysia", "Night Cost WeekDays" : "1000$" , "Night Cost Holidays" : "1200$" , "Family Discount" : "15%"},

];


nightNb=["1","2", "3", "4", "7" , "7 and maybe renewal"];

change(){
  alert("You Will be notified before 2days of the Trip to be Ready!! ")
}

Booked(){
  alert("You booked a trip. You will be remembered with a text message befor 24hrs.")
}
}
