import { ThrowStmt } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-official-page',
  templateUrl: './official-page.component.html',
  styleUrls: ['./official-page.component.css']
})
export class OfficialPageComponent implements OnInit {

  constructor(private _router: Router) { }

  ngOnInit(): void {

  }
  card1 = [
    ["People mainly visit Italy for its rich culture, cuisine, history, fashion, architecture and art. Winter and summer tourism are present in many locations in the Alps and the Apennines, while seaside tourism is widespread in coastal locations along the Mediterranean Sea.", "Italy" , "italy.jpg"] , ["Rich cultural heritage and great natural variety place Russia among the most popular tourist destinations in the world. ... Major tourist routes in Russia include a travel around the Golden Ring of ancient cities, cruises on the big rivers including the Volga, and long journeys on the famous Trans-Siberian Railway.", "Russia", "russia.jpeg"] , ["Finland is a little hidden gem located far up North. While we might be small in size, we're big in things to discover. Our air is one of the cleanest in the world and landscapes are second to none. We are a country of thousands of lakes and forests – which are never far away from wherever you are.", "Finland", "finland.jpeg"]
  ];
 card = [
   ["Maldives, in full Republic of Maldives, also called Maldive Islands, independent island country in the north-central Indian Ocean. It consists of a chain of about 1,200 small coral islands and sandbanks (some 200 of which are inhabited), grouped in clusters, or atolls", "Maldives" , "maldives.jpg"] , ["Turkey is a popular tourist destination known for its Mediterranean coastline, impressive mosques, and stunning natural scenery. But there's also a lot that travelers probably don't know, just some of the most interesting, and surprising facts about Turkey are given below. There are also a few fun facts to keep the little ones entertained.", "Turkey", "turkey.jpg"] , ["Cyprus is known as the birthplace of the Greek goddess Aphrodite, and there are plenty of historical sites dating back to the New Stone Age. Relive history by visiting the island’s many UNESCO-listed sites, Neolithic settlements, Greek temples, and Byzantine churches. For a bit of history mixed with romance, the 16th-century Limassol Castle and Aphrodite's Rock are must-sees in Cyprus.", "Cyprus", "cyprus.jpg"]
 ]

 card2  = [
   ["Austria is one of the leading tourist destinations in Europe. The country's influential history, rich culture, and fascinating landscape attracted over 30 million international tourists prior to the coronavirus (COVID-19) pandemic, making it the seventh most popular European country based on inbound tourist arrivals.", "Austria", "austria.jpg"],["Thailand is one of the prettiest South-Asian countries, which is why Thailand tourism has increased over time. Apart from the attractions of the country's capital city - Bangkok, Thailand is dotted with rainforests, pretty white sand beaches, amazing taverns, beautiful resorts, and many historical temples", "Thailand", "thailand.jpg"], ["Malaysia is a country which is loved by tourists for their visit in SE Asia. This country has something to offer to everyone. You can try a different type of diving, track wild jungles, enjoy beautiful beaches, explore remarkable cities or eat delicious Malaysian food. Everything is included in Malaysia tour package.", "Malaysia", "malaysia.jpg"]
 ]

 BookTrip(){
   this._router.navigate(['/details'])
  
 }

  }
