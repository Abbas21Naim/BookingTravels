import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {

  contact;

  constructor(public dataService : DataService) { }

  ngOnInit(): void {

    this.contact = this.dataService.getcontact();
  }

}
