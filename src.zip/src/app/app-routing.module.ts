import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DetailsComponent } from './details/details.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { OfficialPageComponent } from './official-page/official-page.component';
import { BookingComponent } from './booking/booking.component';


const routes: Routes = [
  { path: "" , pathMatch: "full", redirectTo:"official-page"},
  { path: "official-page", component: OfficialPageComponent},
  { path: "details", component: DetailsComponent},
  { path: "booking", component: BookingComponent},
  { path: "contact-us", component: ContactUsComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
