import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {

  trips;
  selectedTrip;

  constructor( public dataService: DataService) { }

  ngOnInit(): void {

    this.trips = this.dataService.getTrip(); 
  }

  public selectTrip(Trip){
  this.selectedTrip = Trip;
  }
  }

